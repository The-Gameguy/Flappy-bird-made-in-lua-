-- Flappy Bird in LÖVE

-- Game variables
local bird
local birdSpeed = 0
local gravity = 500
local flapStrength = -200
local birdY
local birdX = 100
local pipes = {}
local pipeWidth = 60
local pipeGap = 200
local pipeSpeed = 150
local score = 0
local gameOver = false
local backgroundImage  -- Variable to store background image
local birdImage  -- Variable to store bird image
local birdScale = 0.5  -- Scale factor for the bird image

-- Initialize the game
function love.load()
    birdY = love.graphics.getHeight() / 2
    love.window.setTitle("Flappy Bird!")
    love.window.setMode(0, 0, {fullscreen = true})  -- Set full-screen mode
    
    -- Load the background image from the Assets folder
    backgroundImage = love.graphics.newImage("Assets/background.png")
    
    -- Load the bird image (PNG) from the Assets folder
    birdImage = love.graphics.newImage("Assets/bird.png")
    
    -- Load the music file from the Assets folder
    music = love.audio.newSource("Assets/intense_music.mp3", "stream")  -- Adjust the file name if necessary
    music:setLooping(true)  -- Set the music to loop
    music:play()  -- Start playing the music
end

-- Update the game state
function love.update(dt)
    if gameOver then return end

    -- Bird movement (flap and gravity)
    birdSpeed = birdSpeed + gravity * dt
    birdY = birdY + birdSpeed * dt

    -- Flap the bird when the spacebar is pressed
    if love.keyboard.isDown("space") then
        birdSpeed = flapStrength
    end

    -- Generate new pipes
    if #pipes == 0 or pipes[#pipes].x + pipeWidth < love.graphics.getWidth() - 200 then
        local gapY = love.math.random(100, love.graphics.getHeight() - pipeGap - 100)
        table.insert(pipes, {x = love.graphics.getWidth(), y = gapY})
    end

    -- Move pipes to the left
    for i, pipe in ipairs(pipes) do
        pipe.x = pipe.x - pipeSpeed * dt

        -- Check if the bird passes the pipes (scoring)
        if pipe.x + pipeWidth < birdX and not pipe.scored then
            pipe.scored = true
            score = score + 1
        end
    end

    -- Remove pipes that are off-screen
    for i = #pipes, 1, -1 do
        if pipes[i].x + pipeWidth < 0 then
            table.remove(pipes, i)
        end
    end

    -- Collision detection (bird hitting the ground or pipes)
    if birdY + birdImage:getHeight() * birdScale >= love.graphics.getHeight() or birdY <= 0 then
        gameOver = true
    end

    for _, pipe in ipairs(pipes) do
        if birdX + birdImage:getWidth() * birdScale / 2 > pipe.x and birdX - birdImage:getWidth() * birdScale / 2 < pipe.x + pipeWidth then
            if birdY < pipe.y or birdY + birdImage:getHeight() * birdScale > pipe.y + pipeGap then
                gameOver = true
            end
        end
    end
end

-- Draw the game elements
function love.draw()
    -- Draw the background image, scaled to fit the entire screen
    love.graphics.draw(backgroundImage, 0, 0, 0, love.graphics.getWidth() / backgroundImage:getWidth(), love.graphics.getHeight() / backgroundImage:getHeight())

    -- Draw the bird image with scaling
    love.graphics.draw(birdImage, birdX, birdY, 0, birdScale, birdScale)  -- Apply scale to the bird

    -- Draw the pipes
    love.graphics.setColor(0, 1, 0)  -- Green pipes
    for _, pipe in ipairs(pipes) do
        love.graphics.rectangle("fill", pipe.x, 0, pipeWidth, pipe.y)  -- Top pipe
        love.graphics.rectangle("fill", pipe.x, pipe.y + pipeGap, pipeWidth, love.graphics.getHeight())  -- Bottom pipe
    end

    -- Draw the score
    love.graphics.setColor(1, 1, 1)
    love.graphics.print("Score: " .. score, 20, 20)

    -- Game over screen
    if gameOver then
        love.graphics.setFont(love.graphics.newFont(30))
        love.graphics.print("Game Over! Press R to Restart", love.graphics.getWidth() / 2 - 150, love.graphics.getHeight() / 2)
    end
end

-- Restart the game
function love.keypressed(key)
    if key == "r" and gameOver then
        -- Reset game variables
        birdY = love.graphics.getHeight() / 2
        birdSpeed = 0
        pipes = {}
        score = 0
        gameOver = false
    end
end
